# SDA-SL-MingsDiner-Phase-2-Practice2
A website design for a restuarant named Ming's Diner

A website design for a restaurant template.

This is a work in part of Simplilearn's and Saudi Digital Academy Course: .NET Fullstack Developer Track.

The main objective is a web design of a website a restuarant business.
